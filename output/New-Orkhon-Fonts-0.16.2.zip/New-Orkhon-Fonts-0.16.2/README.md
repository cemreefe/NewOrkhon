# New Orkhon fonts · 0.16.2

BASH's 0.16.1 spacing shift is reverted. Outlines, spacing, kerning and shaping
tables match 0.16 again. No other glyph design changes are introduced.

## Install

The four TTF files in this folder are installable fonts:

| Family | Capital default | Lowercase default |
| --- | --- | --- |
| Serif | NewOrkhonText-Regular.ttf | NewOrkhonTextLowercase-Regular.ttf |
| Sans | NewOrkhonSans-Regular.ttf | NewOrkhonSansLowercase-Regular.ttf |

Each includes all 42 encoded Orkhon signs in both cases. Capital-default fonts
use `ss01` for lowercase; lowercase-default fonts use `ss02` for capitals.
Use logical right-to-left Unicode text, not manually reversed strings.
`kern` controls optical spacing; `liga` controls the EM–I joins.

## Source

`source/` contains the font generator and its dependencies. From that folder:

```sh
python3 -m pip install -r requirements.txt
python3 build.py
```

The four generated fonts appear in `source/`. The build is deterministic.
`bash-spacing-checks.json` records restoration to the archived 0.16 geometry.
This is a focused font bundle, not a replacement for the full presentation package.

## License

The fonts and their source are SIL OFL 1.1; see `OFL.txt`.
This is speculative authored type design, not a recovered historical alphabet.
